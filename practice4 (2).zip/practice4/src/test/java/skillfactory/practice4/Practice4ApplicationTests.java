package skillfactory.practice4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practice4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
